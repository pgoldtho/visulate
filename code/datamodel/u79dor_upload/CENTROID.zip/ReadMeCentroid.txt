In order to protect the package from netnannies in corporations rejecting the zip because it 
contains executable cmd tools, I have renamed all the CMD scripts by replacing the "." with an "_".

So, once you have downloaded and unzipped the archive, rename the following:

installCentroid_cmd to installCentroid.cmd 
(There is no Linux/Unix install.sh script. It will get created at some stage.)

Then run the install.cmd to (optionally) create the schema and load the packages.

If you find errors on install please email me IMMEDIATELY. Also, if you have problems running the code
also email me. If you find the code useful and embed it in your data management processes consider making
a small donation via my website as a lot of work went in to these packages and a little thank you would
be appreciated. If you don't want to throw money, please email me with a thank you or recommendation I
can include on my testimonials page.

Happy Oracling
regards
Simon
